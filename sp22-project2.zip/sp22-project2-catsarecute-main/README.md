# Project 2 Starter Code

This repository contains the starter code for Project 2!

For comprehensive documentation, see the Project 2 Spec (https://proj2.cs161.org/getting-started-coding/).

Write your implementation in `client/client.go`, and your tests in `client_test/client_test.go`.

To test your implementation, run `go test -v` inside of the `client_test` directory.
